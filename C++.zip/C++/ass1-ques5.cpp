#include <iostream>
using namespace std;

int main() {
    int r, c;
    cout << "Enter rows: ";
    cin >> r;
    cout << "Enter columns: ";
    cin >> c;

    int arr[r][c]; // works in GCC

    // Input 2D matrix
    cout << "Enter matrix elements:\n";
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            cin >> arr[i][j];
        }
    }

    // Sum row-wise
    for (int i = 0; i < r; i++) {
        int sum_row = 0;
        for (int j = 0; j < c; j++) {
            sum_row += arr[i][j];
        }
        cout << "Sum of row " << i + 1 << " is " << sum_row << endl;
    }

    return 0;
}
