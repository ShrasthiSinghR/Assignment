#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter n: ";
    cin >> n;

    int arr[n - 1];
    cout << "Enter " << n - 1 << " elements (sorted): ";
    for (int i = 0; i < n - 1; i++) {
        cin >> arr[i];
    }

    int totalSum = n * (n + 1) / 2;
    int arrSum = 0;

    for (int i = 0; i < n - 1; i++) {
        arrSum += arr[i];
    }

    int missing = totalSum - arrSum;

    cout << "Missing number is: " << missing << endl;
    return 0;
}
