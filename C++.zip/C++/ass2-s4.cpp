#include <iostream>
#include <string>
using namespace std;

int main() {
    string str;
    cout << "Enter a sentence: ";
    getline(cin, str);

    string words[50];   // store up to 50 words
    int wordCount = 0;
    string temp = "";

    // Step 1: Extract words manually
    for (int i = 0; i <= str.length(); i++) {
        if (str[i] == ' ' || str[i] == '\0') {
            if (temp != "") {        // avoid empty words
                words[wordCount++] = temp;
                temp = "";
            }
        } else {
            temp += str[i];          // build word character by character
        }
    }

    // Step 2: Sort the words in ascending order (using simple bubble sort)
    for (int i = 0; i < wordCount - 1; i++) {
        for (int j = i + 1; j < wordCount; j++) {
            if (words[i] > words[j]) {   // string comparison
                string tempWord = words[i];
                words[i] = words[j];
                words[j] = tempWord;
            }
        }
    }

    // Step 3: Print sorted words
    cout << "\nWords in ascending order:\n";
    for (int i = 0; i < wordCount; i++) {
        cout << words[i] << endl;
    }

    return 0;
}
