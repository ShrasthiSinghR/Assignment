#include <iostream>
using namespace std;

int main() {
    char ch;
    cout << "Enter an uppercase character: ";
    cin >> ch;

    if (ch >= 'A' && ch <= 'Z') {
        ch = ch + 32;  // convert to lowercase
        cout << "Lowercase character: " << ch;
    } else {
        cout << "Character is not uppercase!";
    }

    return 0;
}
