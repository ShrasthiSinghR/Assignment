#include <iostream>
using namespace std;

int main() {
    int size;
    cout << "Enter size: ";
    cin >> size;

    int arr[size];
    cout << "Enter sorted array elements:\n";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    int se;
    cout << "Enter search element: ";
    cin >> se;

    int low = 0, high = size - 1;
    bool found = false;

    while (low <= high) {
        int mid = (low + high) / 2;

        if (arr[mid] == se) {
            cout << "Element found at index " << mid << endl;
            found = true;
            break;
        } else if (se < arr[mid]) {
            high = mid - 1;
        } else {
            low = mid + 1;
        }
    }

    if (!found)
        cout << "Element not found!" << endl;

    return 0;
}
