#include <iostream>
#include <queue>
#include <string>
using namespace std;

void firstNonRepeating(string s) {
    queue<char> q;
    int freq[26] = {0};  // for 'a'–'z' characters

    for (char ch : s) {
        // step 1: update frequency
        
        freq[ch - 'a']++;

        // step 2: push this char into the queue
        q.push(ch);

        // step 3: remove all repeating characters from front of queue
        while (!q.empty() && freq[q.front() - 'a'] > 1) {
            q.pop();
        }

        // step 4: print current first non-repeating
        if (q.empty())
            cout << "-1 ";
        else
            cout << q.front() << " ";
    }
}

int main() {
    string s;
    cout << "Enter a lowercase string (e.g. aabc): ";
    cin >> s;
    cout << "First non-repeating sequence: ";
    firstNonRepeating(s);
    cout << endl;
    return 0;
}
