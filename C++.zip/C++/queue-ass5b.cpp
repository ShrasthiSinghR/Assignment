#include <iostream>
#include <queue>
using namespace std;

class Stack {
    queue<int> q;

public:
    void push(int x) {
        int n = q.size();
        q.push(x);
        for (int i = 0; i < n; i++) {
            q.push(q.front());
            q.pop();
        }
    }

    void pop() {
        if (q.empty()) {
            cout << "Stack is Empty!" << endl;
            return;
        }
        cout << q.front() << " popped" << endl;
        q.pop();
    }

    void top() {
        if (!q.empty())
            cout << "Top element: " << q.front() << endl;
        else
            cout << "Stack is Empty!" << endl;
    }

    bool isEmpty() {
        return q.empty();
    }
};

int main() {
    Stack s;
    s.push(5);
    s.push(15);
    s.push(25);
    s.top();
    s.pop();
    s.top();
    return 0;
}
