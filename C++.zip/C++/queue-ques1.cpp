#include <iostream>
using namespace std;



class Queue {
    int arr[100];
    int front, rear, size;

public:
    Queue(int s) {
        front = -1;
        rear = -1;
        size = s;
    }

    bool isEmpty() {
        return front == -1;
    }

    bool isFull() {
        return (rear == size - 1);
    }

    void enqueue(int x) {
        if (isFull()) {
            cout << "Queue is Full!" << endl;
            return;
        }
        if (front == -1) front = 0;
        arr[++rear] = x;
        cout << x << " inserted into queue" << endl;
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "Queue is Empty!" << endl;
            return;
        }
        cout << arr[front] << " removed from queue" << endl;
        if (front == rear) {
            front = rear = -1; // queue becomes empty
        } else {
            front++;
        }
    }

    void display() {
        if (isEmpty()) {
            cout << "Queue is Empty!" << endl;
            return;
        }
        cout << "Queue elements: ";
        for (int i = front; i <= rear; i++)
            cout << arr[i] << " ";
        cout << endl;
    }

    void peek() {
        if (!isEmpty())
            cout << "Front element: " << arr[front] << endl;
        else
            cout << "Queue is Empty!" << endl;
    }
};

int main() {
    int size, choice, val;
    cout << "Enter size of queue: ";
    cin >> size;

    Queue q(size);

    do {
        cout << "\n--- MENU ---\n";
        cout << "1. Enqueue\n2. Dequeue\n3. Display\n4. Peek\n5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value: ";
                cin >> val;
                q.enqueue(val);
                break;
            case 2:
                q.dequeue();
                break;
            case 3:
                q.display();
                break;
            case 4:
                q.peek();
                break;
            case 5:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice!\n";
        }
    } while (choice != 5);

    return 0;
}
