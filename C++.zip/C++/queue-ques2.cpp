#include <iostream>
using namespace std;



class CircularQueue {
    int arr[100];
    int front, rear, size;

public:
    CircularQueue(int s) {
        front = -1;
        rear = -1;
        size = s;
    }

    bool isEmpty() {
        return front == -1;
    }

    bool isFull() {
        return (front == (rear + 1) % size);
    }

    void enqueue(int x) {
        if (isFull()) {
            cout << "Queue is Full!\n";
            return;
        }
        if (front == -1) front = 0;
        rear = (rear + 1) % size;
        arr[rear] = x;
        cout << x << " inserted.\n";
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "Queue is Empty!\n";
            return;
        }
        cout << arr[front] << " removed.\n";
        if (front == rear)
            front = rear = -1;
        else
            front = (front + 1) % size;
    }

    void display() {
        if (isEmpty()) {
            cout << "Queue is Empty!\n";
            return;
        }
        cout << "Queue elements: ";
        int i = front;
        while (true) {
            cout << arr[i] << " ";
            if (i == rear) break;
            i = (i + 1) % size;
        }
        cout << endl;
    }

    void peek() {
        if (!isEmpty())
            cout << "Front element: " << arr[front] << endl;
        else
            cout << "Queue is Empty!\n";
    }
};

int main() {
    int size, choice, val;
    cout << "Enter size of circular queue: ";
    cin >> size;

    CircularQueue cq(size);

    do {
        cout << "\n--- MENU ---\n";
        cout << "1. Enqueue\n2. Dequeue\n3. Display\n4. Peek\n5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value: ";
                cin >> val;
                cq.enqueue(val);
                break;
            case 2:
                cq.dequeue();
                break;
            case 3:
                cq.display();
                break;
            case 4:
                cq.peek();
                break;
            case 5:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice!\n";
        }
    } while (choice != 5);

    return 0;
}
