#include<iostream>
#include<string>
#include<stack>
using namespace std;

bool isBalanced(string expr)
{
    stack<char> s;
    for (int i = 0; i < expr.length(); i++)
    {
        char ch = expr[i];

        if (ch == '(' || ch == '{' || ch == '[')
        {
            s.push(ch);
        }
        else if (ch == ')' || ch == '}' || ch == ']')
        {
            if (s.empty())
            {
                return false; 
            }

            char top = s.top();
            s.pop();

            if ((ch == ')' && top != '(') ||
                (ch == '}' && top != '{') ||
                (ch == ']' && top != '['))
            {
                return false; 
            }
        }
    }

  
    return true;
}

int main()
{
    string exp;
    cout<<"enter an expression"<<endl;
    getline(cin,exp);

    if(isBalanced(exp))
    {
        cout<<"valid"<<endl;
    }
    else
    {
        cout<<"invalid exp"<<endl;
    }
    return 0;
}