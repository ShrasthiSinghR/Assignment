#include <iostream>
#include <stack>
#include <string>
#include <cmath>    // for pow()
using namespace std;

// Function to evaluate a postfix expression
int evaluatePostfix(string expr) {
    stack<int> s;

    for (char ch : expr) {
        // If operand (digit), push to stack
        if (isdigit(ch)) {
            s.push(ch - '0'); // convert char to int
        }
        // If operator, pop two operands and apply
        else {
            int op2 = s.top(); s.pop();
            int op1 = s.top(); s.pop();
            int result;

            switch (ch) {
                case '+': result = op1 + op2; break;
                case '-': result = op1 - op2; break;
                case '*': result = op1 * op2; break;
                case '/': result = op1 / op2; break;
                case '^': result = pow(op1, op2); break;
                default: cout << "Invalid operator " << ch << endl; return -1;
            }

            s.push(result);
        }
    }

    return s.top(); // final result
}

int main() {
    string expr;
    cout << "Enter a postfix expression (single-digit operands): ";
    cin >> expr;

    int result = evaluatePostfix(expr);
    cout << "Result: " << result << endl;

    return 0;
}
