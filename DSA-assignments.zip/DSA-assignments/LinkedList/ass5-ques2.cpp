#include <iostream>
using namespace std;

// Node class
class Node {
public:
    int data;
    Node* next;
    Node(int val) {
        data = val;
        next = NULL;
    }
};

// LinkedList class
class LinkedList {
    Node* head;
public:
    LinkedList() {
        head = NULL;
    }

    // Function to insert node at end
    void insertAtEnd(int val) {
        Node* newNode = new Node(val);
        if (head == NULL) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = newNode;
    }

    // Function to count and delete all occurrences of key
    int countAndDeleteKey(int key) {
        int count = 0;

        // Delete occurrences at the beginning
        while (head != NULL && head->data == key) {
            Node* temp = head;
            head = head->next;
            delete temp;
            count++;
        }

        // Delete occurrences in the rest of the list
        Node* current = head;
        while (current != NULL && current->next != NULL) {
            if (current->next->data == key) {
                Node* temp = current->next;
                current->next = current->next->next;
                delete temp;
                count++;
            } else {
                current = current->next;
            }
        }

        return count;
    }

    // Function to display list
    void display() {
        if (head == NULL) {
            cout << "List is empty.";
            return;
        }
        Node* temp = head;
        while (temp != NULL) {
            cout << temp->data;
            if (temp->next != NULL) cout << " -> ";
            temp = temp->next;
        }
    }
};

int main() {
    LinkedList list;
    int n, val, key;

    cout << "Enter number of nodes: ";
    cin >> n;

    cout << "Enter elements of linked list:\n";
    for (int i = 0; i < n; i++) {
        cin >> val;
        list.insertAtEnd(val);
    }

    cout << "Enter key to delete: ";
    cin >> key;

    int count = list.countAndDeleteKey(key);

    cout << "\nCount of key " << key << ": " << count << endl;
    cout << "Updated Linked List: ";
    list.display();
    cout << endl;

    return 0;
}
