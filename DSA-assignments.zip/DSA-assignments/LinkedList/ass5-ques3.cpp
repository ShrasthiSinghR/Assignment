#include <iostream>
using namespace std;

// Node class
class Node {
public:
    int data;
    Node* next;
    Node(int val) {
        data = val;
        next = NULL;
    }
};

// Linked List class
class LinkedList {
    Node* head;
public:
    LinkedList() {
        head = NULL;
    }

    // Insert node at end
    void insertAtEnd(int val) {
        Node* newNode = new Node(val);
        if (head == NULL) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = newNode;
    }

    // Function to find middle using count
    void findMiddle() {
        if (head == NULL) {
            cout << "List is empty." << endl;
            return;
        }

        // Step 1: Count total nodes
        int count = 0;
        Node* temp = head;
        while (temp != NULL) {
            count++;
            temp = temp->next;
        }

        // Step 2: Find middle index
        int mid = count / 2;

        // Step 3: Traverse again to middle
        temp = head;
        for (int i = 0; i < mid; i++) {
            temp = temp->next;
        }

        cout << "Middle element: " << temp->data << endl;
    }

    // Display all nodes
    void display() {
        Node* temp = head;
        while (temp != NULL) {
            cout << temp->data;
            if (temp->next != NULL)
                cout << " -> ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    LinkedList list;
    int n, val;

    cout << "Enter number of nodes: ";
    cin >> n;

    cout << "Enter elements of linked list:\n";
    for (int i = 0; i < n; i++) {
        cin >> val;
        list.insertAtEnd(val);
    }

    cout << "Linked List: ";
    list.display();

    list.findMiddle();

    return 0;
}
