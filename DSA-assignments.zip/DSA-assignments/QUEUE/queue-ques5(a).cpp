#include <iostream>
#include <queue>
using namespace std;

class StackUsingTwoQueues {
    queue<int> q1, q2;

public:

    // push is costly
    void push(int x) {
        // Step 1: Push x into q2
        q2.push(x);

        // Step 2: Move all elements of q1 → q2
        while (!q1.empty()) {
            q2.push(q1.front());
            q1.pop();
        }

        // Step 3: Swap q1 and q2
        swap(q1, q2);

        cout << x << " pushed into stack\n";
    }

    // pop is easy
    void pop() {
        if (q1.empty()) {
            cout << "Stack is empty\n";
            return;
        }
        cout << q1.front() << " popped\n";
        q1.pop();
    }

    // return top element
    int top() {
        if (q1.empty()) {
            cout << "Stack is empty\n";
            return -1;
        }
        return q1.front();
    }

    bool empty() {
        return q1.empty();
    }
};

int main() {
    StackUsingTwoQueues st;

    st.push(10);
    st.push(20);
    st.push(30);

    cout << "Top = " << st.top() << endl;

    st.pop();
    st.pop();

    cout << "Top = " << st.top() << endl;

    return 0;
}
