#include <iostream>
#include <queue>
using namespace std;

class StackUsingOneQueue {
    queue<int> q;

public:

    // Push element (costly)
    void push(int x) {
        q.push(x);
        int size = q.size();

        // Rotate to bring x to the front
        for (int i = 0; i < size - 1; i++) {
            q.push(q.front());
            q.pop();
        }
        cout << x << " pushed\n";
    }

    // Pop element
    void pop() {
        if (q.empty()) {
            cout << "Stack is empty\n";
            return;
        }
        cout << q.front() << " popped\n";
        q.pop();
    }

    // Get top element
    int top() {
        if (q.empty()) {
            cout << "Stack is empty\n";
            return -1;
        }
        return q.front();
    }

    bool empty() {
        return q.empty();
    }
};

int main() {
    StackUsingOneQueue st;

    st.push(10);
    st.push(20);
    st.push(30);

    cout << "Top = " << st.top() << endl; // 30

    st.pop();  // 30 popped
    st.pop();  // 20 popped

    cout << "Top = " << st.top() << endl; // 10

    return 0;
}
