#include <iostream>
#include <stack>
using namespace std;

void nearestSmallerToLeft(int A[], int n) {
    stack<int> st;
    int result[n]; 

    for (int i = 0; i < n; i++) {
        // Pop all elements greater than or equal to A[i]
        while (!st.empty() && st.top() >= A[i])
            st.pop();

        // If stack is empty → no smaller element
        if (st.empty())
            result[i] = -1;
        else
            result[i] = st.top();

        // Push current element
        st.push(A[i]);
    }

    // Print the result
    cout << "Nearest smaller to left: ";
    for (int i = 0; i < n; i++)
        cout << result[i] << " ";
    cout << endl;
}

int main() {
    int A[] = {4, 5, 2, 10, 8};
    int n = sizeof(A) / sizeof(A[0]);

    nearestSmallerToLeft(A, n);

    return 0;
}
