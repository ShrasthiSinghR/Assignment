#include <iostream>
#include <stack>
using namespace std;

void nextGreaterElement(int arr[], int n) {
    int ans[n];       // Array to store results
    stack<int> st;    // Stack to hold potential NGE elements

    // Traverse from right to left
    for (int i = n - 1; i >= 0; i--) {
        // Remove all smaller or equal elements
        while (!st.empty() && st.top() <= arr[i]) {
            st.pop();
        }

        // If stack is empty, NGE doesn't exist
        if (st.empty())
            ans[i] = -1;
        else
            ans[i] = st.top(); // Top is the next greater element

        // Push current element into the stack
        st.push(arr[i]);
    }

    // Print the results
    for (int i = 0; i < n; i++) {
        cout << ans[i] << " ";
    }
}

int main() {
    int arr[] = {1, 3, 2, 4};
    int n = sizeof(arr) / sizeof(arr[0]);

    nextGreaterElement(arr, n);

    return 0;
}
