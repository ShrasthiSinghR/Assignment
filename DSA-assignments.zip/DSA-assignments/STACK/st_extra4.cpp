#include <iostream>
#include <stack>
using namespace std;

void dailyTemperatures(int temp[], int n) {
    int ans[n] = {0};
    stack<int> st; // store indices

    for (int i = n - 1; i >= 0; i--) {
        while (!st.empty() && temp[st.top()] <= temp[i]) {
            st.pop();
        }

        if (!st.empty())
            ans[i] = st.top() - i;
        else
            ans[i] = 0;

        st.push(i);
    }

    for (int i = 0; i < n; i++)
        cout << ans[i] << " ";
}

int main() {
    int temp[] = {73, 74, 75, 71, 69, 72, 76, 73};
    int n = sizeof(temp) / sizeof(temp[0]);
    dailyTemperatures(temp, n);
    return 0;
}
