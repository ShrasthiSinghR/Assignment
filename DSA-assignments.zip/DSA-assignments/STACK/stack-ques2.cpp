#include<iostream>
#include<string>
using namespace std;

class Stack{
    char arr[100];
    int top;

public:
Stack()
{
    top=-1;
}
void push(char c)
{
    if(top<99)
    {
        arr[++top]=c;

    }
    else
    cout<<"stack overflow"<<endl;
}
char pop()
{
    if(top>=0)
    return arr[top--];
    else
    return '/0';
}
bool isEmpty()
{
    return (top==-1)
}
};
int main(
    string str;
    cout<<"enter a string:"<<endl;
    getline(cin,str);

    Stack s;
    int n=str.length();
    for(int i=0;i<n;i++)
    {
        char ch=str[i];
        s.push(ch);

    }
    string reversed="";
    while(!s.isEmpty())
    reversed+=s.pop();


    cout<<"reversed string is"<<reversed<<endl;
    return 0;
    

)

