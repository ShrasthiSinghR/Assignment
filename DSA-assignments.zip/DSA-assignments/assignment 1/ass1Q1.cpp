#include<iostream>
using namespace std;
int main()
{
    int arr[100];
    int n;
    int choice;
    int pos,element;
    bool found;
    do
    {
         cout << " MENU ";
        cout << "1. CREATE\n";
        cout << "2. DISPLAY\n";
        cout << "3. INSERT\n";
        cout << "4. DELETE\n";
        cout << "5. LINEAR SEARCH\n";
        cout << "6. EXIT\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {

            // CREATE
            case 1:
                cout << "Enter number of elements: ";
                cin >> n;
                cout << "Enter " << n << " elements:\n";
                for(int i = 0; i < n; i++) {
                    cin >> arr[i];
                }
                break;

            // DISPLAY
            case 2:
                cout << "Array elements are:\n";
                for(int i = 0; i < n; i++) {
                    cout << arr[i] << " ";
                }
                cout << endl;
                break;

            // INSERT
            case 3:
                cout << "Enter position to insert (0-based index): ";
                cin >> pos;
                cout << "Enter element to insert: ";
                cin >> element;
                if(pos < 0 || pos > n) {
                    cout << "Invalid position!\n";
                } else {
                    for(int i = n; i > pos; i--) {
                        arr[i] = arr[i - 1];
                    }
                    arr[pos] = element;
                    n++;
                    cout << "Element inserted successfully!\n";
                }
                break;

            // DELETE
            case 4:
                cout << "Enter position to delete (0-based index): ";
                cin >> pos;
                if(pos < 0 || pos >= n) {
                    cout << "Invalid position!\n";
                } else {
                    for(int i = pos; i < n - 1; i++) {
                        arr[i] = arr[i + 1];
                    }
                    n--;
                    cout << "Element deleted successfully!\n";
                }
                break;

            // LINEAR SEARCH
            case 5:
                cout << "Enter element to search: ";
                cin >> element;
                found = false;
                for(int i = 0; i < n; i++) {
                    if(arr[i] == element) {
                        cout << "Element found at position " << i << endl;
                        found = true;
                        break;
                    }
                }
                if(!found) {
                    cout << "Element not found!\n";
                }
                break;

            // EXIT
            case 6:
                cout << "Exiting program...\n";
                break;

            default:
                cout << "Invalid choice! Try again.\n";
        }


    }while (choice!=6);
    return 0;
}
    

