#include <iostream>
#include <string>
using namespace std;

int main() {
    string str, result = "";
    cout << "Enter a string: ";
    getline(cin, str);
    int n=str.length();

    for (int i=0;i<n;i++)
    {
        char ch=str[i];
        if (ch!='a' && ch!='e' && ch!='i' && ch!='o' && ch!='u' &&
            ch!='A' && ch!='E' && ch!='I' && ch!='O' && ch!='U')
            result += ch;
    }

    cout << "String without vowels: " << result;
    return 0;
}
