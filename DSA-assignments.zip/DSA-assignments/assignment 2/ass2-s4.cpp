#include <iostream>
#include <string>
using namespace std;

int main() {

    string str;
    cout << "Enter a string: ";
    getline(cin, str);

    // Step 1: Count words
    int wordcount = 1;    // start with 1 word
    for (int i = 0; i < str.length(); i++) {
        if (str[i] == ' ')
            wordcount++;
    }

    // Step 2: Split into words
    string words[100];    // safe size
    string w = "";
    int index = 0;

    for (int i = 0; i < str.length(); i++) {
        char ch = str[i];

        if (ch != ' ') {
            w += ch;
        } else {
            words[index] = w;
            index++;
            w = "";
        }
    }

    // store the last word
    words[index] = w;

    //  (Bubble Sort)
  for (int i = 0; i < wordcount - 1; i++) {
    for (int j = 0; j < wordcount - i - 1; j++) {
        if (words[j] > words[j+1]) {
            string temp = words[j];
            words[j] = words[j+1];
            words[j+1] = temp;
        }
    }
}


    // Step 4: Print sorted words
    cout << "\nWords sorted alphabetically:\n";
    for (int i = 0; i < wordcount; i++) {
        cout << words[i] << endl;
    }

    return 0;
}


