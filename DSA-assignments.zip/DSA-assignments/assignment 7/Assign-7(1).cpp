#include <iostream>
#include<vector>
using namespace std;

// swap
void swap(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

// selection sorting 
void selectionSort(int arr[], int n) {
    for(int i = 0; i < n-1; i++) {
        int minIndex = i;
        for(int j = i+1; j < n; j++) {
            if(arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        swap(arr[i], arr[minIndex]);
    }
}

// insertion sorting 

void insertionSort(int arr[], int n) {
    for(int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;

        while(j >= 0 && arr[j] > key) {
            arr[j+1] = arr[j];
            j--;
        }
        arr[j+1] = key;
    }
}

//bubblesort
void bubbleSort(int arr[], int n) {
    for(int i = 0; i < n-1; i++) {
        for(int j = 0; j < n-i-1; j++) {
            if(arr[j] > arr[j+1]) {
                swap(arr[j], arr[j+1]);
            }
        }
    }
}

//merge sort
void merge(int arr[], int l, int m, int r) {
     vector<int> temp;     // single temp vector
    int i = l, j = m + 1;

    // Merge both halves into temp
    while (i <= m && j <= r) {
        if (arr[i] <= arr[j]) {
            temp.push_back(arr[i]);
            i++;
        } else {
            temp.push_back(arr[j]);
            j++;
        }
    }

    // Copy remaining elements
    while (i <= m) {
        temp.push_back(arr[i]);
        i++;
    }
    while (j <= r) {
        temp.push_back(arr[j]);
        j++;
    }

    // Copy back to original array
    for (int k = 0; k < temp.size(); k++) {
        arr[l + k] = temp[k];
    }
}

void mergeSort(int arr[], int l, int r) {
    if(l < r) {
        int m = (l + r) / 2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}

// quick sort 
int partitionFunction(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = low - 1;

    for(int j = low; j < high; j++) {
        if(arr[j] < pivot) {
            i++;
            swap(arr[i], arr[j]); 
        }
    }

    swap(arr[i+1], arr[high]);
    return i + 1;
}

void quickSort(int arr[], int low, int high) {
    if(low < high) {
        int pi = partitionFunction(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}


void printArray(int arr[], int n) {
    for(int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;
}

void copyArray(int src[], int dest[], int n) {
    for(int i = 0; i < n; i++)
        dest[i] = src[i];
}



int main() {
    int n;
    cout << "Enter number of elements: ";
    cin >> n;

    int arr[50], temp[50];

    cout << "Enter elements:\n";
    for(int i = 0; i < n; i++)
        cin >> arr[i];

    int choice;
    do {
        cout << "\n----- MENU -----\n";
        cout << "1. Selection Sort\n";
        cout << "2. Insertion Sort\n";
        cout << "3. Bubble Sort\n";
        cout << "4. Merge Sort\n";
        cout << "5. Quick Sort\n";
        cout << "6. Exit\n";
        cout << "Choose option: ";
        cin >> choice;

        copyArray(arr, temp, n);

        switch(choice) {
            case 1:
                selectionSort(temp, n);
                cout << "Selection Sorted: ";
                printArray(temp, n);
                break;

            case 2:
                insertionSort(temp, n);
                cout << "Insertion Sorted: ";
                printArray(temp, n);
                break;

            case 3:
                bubbleSort(temp, n);
                cout << "Bubble Sorted: ";
                printArray(temp, n);
                break;

            case 4:
                mergeSort(temp, 0, n-1);
                cout << "Merge Sorted: ";
                printArray(temp, n);
                break;

            case 5:
                quickSort(temp, 0, n-1);
                cout << "Quick Sorted: ";
                printArray(temp, n);
                break;

            case 6:
                cout << "Exiting...\n";
                break;

            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while(choice != 6);

    return 0;
}
