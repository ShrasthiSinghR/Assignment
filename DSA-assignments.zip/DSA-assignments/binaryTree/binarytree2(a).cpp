#include <iostream>
using namespace std;

// Node class
class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = nullptr;
    }
};

// BST class
class BST {
public:
    Node* root;

    BST() {
        root = nullptr;
    }

    // Function to insert a node in BST
    Node* insert(Node* node, int val) {
        if (node == nullptr)
            return new Node(val);

        if (val < node->data)
            node->left = insert(node->left, val);
        else if (val > node->data)
            node->right = insert(node->right, val);

        return node;
    }

    // (a) Recursive Search Function
    Node* searchRecursive(Node* node, int key) {
        if (node == nullptr || node->data == key)
            return node;

        if (key < node->data)
            return searchRecursive(node->left, key);
        else
            return searchRecursive(node->right, key);
    }

    // (a) Non-Recursive Search Function
    Node* searchIterative(Node* node, int key) {
        while (node != nullptr) {
            if (key == node->data)
                return node;
            else if (key < node->data)
                node = node->left;
            else
                node = node->right;
        }
        return nullptr;
    }

    // Inorder traversal (to show the tree)
    void inorder(Node* node) {
        if (node == nullptr)
            return;
        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }
};

// ---------------------- MAIN FUNCTION ----------------------
int main() {
    BST tree;
    int n, val, key;

    cout << "Enter number of nodes: ";
    cin >> n;

    cout << "Enter elements to insert in BST:\n";
    for (int i = 0; i < n; i++) {
        cin >> val;
        tree.root = tree.insert(tree.root, val);
    }

    cout << "\nInorder Traversal of BST: ";
    tree.inorder(tree.root);
    cout << endl;

    cout << "\nEnter element to search: ";
    cin >> key;

    // Recursive Search
    Node* res1 = tree.searchRecursive(tree.root, key);
    if (res1)
        cout << "Recursive Search: " << key << " found in BST.\n";
    else
        cout << "Recursive Search: " << key << " not found in BST.\n";

    // Iterative Search
    Node* res2 = tree.searchIterative(tree.root, key);
    if (res2)
        cout << "Iterative Search: " << key << " found in BST.\n";
    else
        cout << "Iterative Search: " << key << " not found in BST.\n";

    return 0;
}
