#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = nullptr;
    }
};

class BST {
public:
    Node* root;

    BST() {
        root = nullptr;
    }

    // Insert node in BST
    Node* insert(Node* node, int val) {
        if (node == nullptr)
            return new Node(val);

        if (val < node->data)
            node->left = insert(node->left, val);
        else if (val > node->data)
            node->right = insert(node->right, val);

        return node;
    }

    // ---------------------------
    // (b) Find Minimum - Iterative
    Node* findMinIterative(Node* node) {
        if (node == nullptr)
            return nullptr;
        while (node->left != nullptr)
            node = node->left;
        return node;
    }

    // (b) Find Minimum - Recursive
    Node* findMinRecursive(Node* node) {
        if (node == nullptr || node->left == nullptr)
            return node;
        return findMinRecursive(node->left);
    }

    // ---------------------------
    // (c) Find Maximum - Iterative
    Node* findMaxIterative(Node* node) {
        if (node == nullptr)
            return nullptr;
        while (node->right != nullptr)
            node = node->right;
        return node;
    }

    // (c) Find Maximum - Recursive
    Node* findMaxRecursive(Node* node) {
        if (node == nullptr || node->right == nullptr)
            return node;
        return findMaxRecursive(node->right);
    }

    // Inorder traversal for visualization
    void inorder(Node* node) {
        if (node == nullptr)
            return;
        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }
};

int main() {
    BST tree;
    int values[] = {50, 30, 70, 20, 40, 60, 80};

    for (int val : values)
        tree.root = tree.insert(tree.root, val);

    cout << "Inorder Traversal: ";
    tree.inorder(tree.root);
    cout << endl;

    Node* minIter = tree.findMinIterative(tree.root);
    Node* minRec = tree.findMinRecursive(tree.root);
    Node* maxIter = tree.findMaxIterative(tree.root);
    Node* maxRec = tree.findMaxRecursive(tree.root);

    cout << "Minimum (Iterative): " << minIter->data << endl;
    cout << "Minimum (Recursive): " << minRec->data << endl;
    cout << "Maximum (Iterative): " << maxIter->data << endl;
    cout << "Maximum (Recursive): " << maxRec->data << endl;

    return 0;
}
