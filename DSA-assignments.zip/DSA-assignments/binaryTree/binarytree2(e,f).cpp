#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = nullptr;
    }
};

class BST {
public:
    Node* root;
    int inorderArr[100];  // static array to store inorder traversal
    int index;            // current index in array

    BST() {
        root = nullptr;
        index = 0;
    }

    // Insert node into BST
    Node* insert(Node* node, int val) {
        if (node == nullptr)
            return new Node(val);

        if (val < node->data)
            node->left = insert(node->left, val);
        else if (val > node->data)
            node->right = insert(node->right, val);

        return node;
    }

    // Inorder traversal to fill array
    void inorder(Node* node) {
        if (node == nullptr)
            return;

        inorder(node->left);
        inorderArr[index++] = node->data;  // store data in array
        inorder(node->right);
    }

    // Find predecessor and successor using array
    void findPreSuc(int key) {
        // Perform inorder traversal to fill array
        index = 0;
        inorder(root);

        int predecessor = -1, successor = -1;
        bool found = false;

        // Search the key in the inorder array
        for (int i = 0; i < index; i++) {
            if (inorderArr[i] == key) {
                found = true;
                if (i > 0)
                    predecessor = inorderArr[i - 1];
                if (i < index - 1)
                    successor = inorderArr[i + 1];
                break;
            }
        }

        if (!found)
            cout << "Key not found in BST.\n";
        else {
            if (predecessor != -1)
                cout << "Inorder Predecessor of " << key << " = " << predecessor << endl;
            else
                cout << "No Inorder Predecessor (smallest element)\n";

            if (successor != -1)
                cout << "Inorder Successor of " << key << " = " << successor << endl;
            else
                cout << "No Inorder Successor (largest element)\n";
        }
    }

    // Display inorder traversal (optional)
    void displayInorder() {
        index = 0;
        inorder(root);
        cout << "Inorder Traversal: ";
        for (int i = 0; i < index; i++)
            cout << inorderArr[i] << " ";
        cout << endl;
    }
};

int main() {
    BST tree;
    int n, val, key;

    cout << "Enter number of nodes: ";
    cin >> n;

    cout << "Enter elements to insert in BST:\n";
    for (int i = 0; i < n; i++) {
        cin >> val;
        tree.root = tree.insert(tree.root, val);
    }

    tree.displayInorder();

    cout << "Enter key to find predecessor and successor: ";
    cin >> key;

    tree.findPreSuc(key);

    return 0;
}
