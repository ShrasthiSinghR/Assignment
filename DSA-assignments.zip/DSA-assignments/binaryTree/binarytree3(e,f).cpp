#include <iostream>
#include <algorithm>  // for max() and min()
using namespace std;

// Node structure
class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = nullptr;
    }
};

// BST Class
class BST {
public:
    Node* root;

    BST() {
        root = nullptr;
    }

    // Insert node into BST (no duplicates)
    Node* insert(Node* node, int val) {
        if (node == nullptr)
            return new Node(val);

        if (val < node->data)
            node->left = insert(node->left, val);
        else if (val > node->data)
            node->right = insert(node->right, val);
        else
            cout << "Duplicate value not allowed!\n";

        return node;
    }

    // Inorder traversal
    void inorder(Node* node) {
        if (node == nullptr)
            return;
        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }

    // Function to find maximum height (longest root-to-leaf path)
    int maxHeight(Node* root) {
        if (root == nullptr)
            return 0;
        return 1 + max(maxHeight(root->left), maxHeight(root->right));
    }

    // Function to find minimum height (shortest root-to-leaf path)
    int minHeight(Node* root) {
        if (root == nullptr)
            return 0;

        // if left is null, go right
        if (root->left == nullptr)
            return 1 + minHeight(root->right);

        // if right is null, go left
        if (root->right == nullptr)
            return 1 + minHeight(root->left);

        // if both exist, take smaller one
        return 1 + min(minHeight(root->left), minHeight(root->right));
    }
};

int main() {
    BST tree;
    int n, val;

    cout << "Enter number of nodes: ";
    cin >> n;

    cout << "Enter elements to insert in BST:\n";
    for (int i = 0; i < n; i++) {
        cin >> val;
        tree.root = tree.insert(tree.root, val);
    }

    cout << "\nInorder Traversal of BST: ";
    tree.inorder(tree.root);
    cout << endl;

    int maxH = tree.maxHeight(tree.root);
    int minH = tree.minHeight(tree.root);

    cout << "\nMaximum Height of BST = " << maxH;
    cout << "\nMinimum Height of BST = " << minH << endl;

    return 0;
}
