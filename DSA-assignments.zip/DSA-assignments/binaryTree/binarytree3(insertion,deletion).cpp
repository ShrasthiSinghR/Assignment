#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = nullptr;
    }
};

class BST {
public:
    Node* root;
    int inorderArr[100];
    int index;

    BST() {
        root = nullptr;
        index = 0;
    }

    // Insert node (no duplicates)
    Node* insert(Node* node, int val) {
        if (node == nullptr)
            return new Node(val);

        if (val < node->data)
            node->left = insert(node->left, val);
        else if (val > node->data)
            node->right = insert(node->right, val);
        else
            cout << "Duplicate values not allowed!\n";

        return node;
    }

    // Inorder traversal to fill array
    void inorder(Node* node) {
        if (node == nullptr)
            return;
        inorder(node->left);
        inorderArr[index++] = node->data;
        inorder(node->right);
    }

    // Find inorder successor using array logic
    int findSuccessor(Node* root, int key) {
        index = 0;
        inorder(root);

        for (int i = 0; i < index - 1; i++) {
            if (inorderArr[i] == key)
                return inorderArr[i + 1]; // next element is successor
        }
        return -1; // no successor
    }

    // Find inorder predecessor using array logic
    int findPredecessor(Node* root, int key) {
        index = 0;
        inorder(root);

        for (int i = 1; i < index; i++) {
            if (inorderArr[i] == key)
                return inorderArr[i - 1]; // previous element is predecessor
        }
        return -1; // no predecessor
    }

    // Delete a node using successor (found from array)
    Node* deleteNode(Node* node, int key) {
        if (node == nullptr)
            return node;

        if (key < node->data)
            node->left = deleteNode(node->left, key);
        else if (key > node->data)
            node->right = deleteNode(node->right, key);
        else {
            // Node found
            // Case 1: No children
            if (node->left == nullptr && node->right == nullptr) {
                delete node;
                return nullptr;
            }

            // Case 2: One child
            else if (node->left == nullptr) {
                Node* temp = node->right;
                delete node;
                return temp;
            } else if (node->right == nullptr) {
                Node* temp = node->left;
                delete node;
                return temp;
            }

            // Case 3: Two children (use inorder successor via array)
            else {
                int successorVal = findSuccessor(root, node->data);
                node->data = successorVal;
                node->right = deleteNode(node->right, successorVal);
            }
        }
        return node;
    }

    // Display inorder traversal
    void displayInorder(Node* node) {
        if (node == nullptr)
            return;
        displayInorder(node->left);
        cout << node->data << " ";
        displayInorder(node->right);
    }
};

int main() {
    BST tree;
    int n, val, key;

    cout << "Enter number of nodes: ";
    cin >> n;

    cout << "Enter elements to insert into BST:\n";
    for (int i = 0; i < n; i++) {
        cin >> val;
        tree.root = tree.insert(tree.root, val);
    }

    cout << "\nInorder Traversal before deletion: ";
    tree.displayInorder(tree.root);

    cout << "\nEnter node to delete: ";
    cin >> key;

    tree.root = tree.deleteNode(tree.root, key);

    cout << "Inorder Traversal after deletion: ";
    tree.displayInorder(tree.root);
    cout << endl;

    return 0;
}
