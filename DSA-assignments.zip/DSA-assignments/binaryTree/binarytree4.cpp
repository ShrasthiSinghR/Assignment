#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = nullptr;
    }
};

class BSTChecker {
public:
    int arr[100];  // store inorder traversal
    int idx;

    BSTChecker() {
        idx = 0;
    }

    // Inorder traversal
    void inorder(Node* node) {
        if (node == nullptr)
            return;
        inorder(node->left);
        arr[idx++] = node->data;
        inorder(node->right);
    }

    // Check if array is strictly increasing
    bool isSorted() {
        for (int i = 1; i < idx; i++) {
            if (arr[i] <= arr[i - 1])
                return false;
        }
        return true;
    }

    bool isBST(Node* root) {
        idx = 0;
        inorder(root);
        return isSorted();
    }
};

int main() {
    // Example tree
    Node* root = new Node(50);
    root->left = new Node(30);
    root->right = new Node(70);
    root->left->left = new Node(20);
    root->left->right = new Node(40);
    root->right->left = new Node(60);
    root->right->right = new Node(80);

    BSTChecker checker;
    if (checker.isBST(root))
        cout << "Tree is a Binary Search Tree.\n";
    else
        cout << "Tree is NOT a Binary Search Tree.\n";

    return 0;
}
